from django.core.mail import send_mail
from .models import Event, Template
import datetime

def send_event_emails():
    events = Event.objects.filter(event_date=datetime.date.today())
    for event in events:
        template = event.event_type
        employee = event.employee
        send_mail(template.subject, template.body, 'sender@example.com', [employee.email], fail_silently=False)
