from django.db import models

class Employee(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()

class Template(models.Model):
    event_type = models.CharField(max_length=50)
    subject = models.CharField(max_length=200)
    body = models.TextField()

class Event(models.Model):
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    event_date = models.DateField()
    event_type = models.ForeignKey(Template, on_delete=models.CASCADE)
